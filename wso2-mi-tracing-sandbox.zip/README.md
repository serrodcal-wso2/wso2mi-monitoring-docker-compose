# wso2mi-monitoring-docker-compose

> curl http://localhost:8290/health/doctor/hospital/SVQ002 -H 'Content-Type: application/json' -w "\n" | jq -c

> wrk -d10s -t1 -c 1 http://localhost:8290/health/doctor/hospital/SVQ002
